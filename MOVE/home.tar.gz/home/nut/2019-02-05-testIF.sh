#!/bin/bash
MY_SHELL="c1sh"
if [ "$MY_SHELL" = "bash" ]
	then	echo "You seem to like the bash shell."
elif [ "$MY_SHELL" = "csh" ]
	then	echo "You seem to like the csh shell."
else 	echo "You don't seem to like the bash or csh shells."
fi

for COLOR in red grenn blue yellow pink
do
	echo "COLOR : $COLOR "
done
