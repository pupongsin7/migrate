#!/bin/bash
for user in $@
do
echo "Executing script:$0"
echo "Archiving user : $1"

#lock the account
passwd -l $user
tar cf /archives/${user}.tar.gz /home/${user}
done

