#!/bin/bash
MY_SHELL="bash"
echo "I Like the $MY_SHELL shell."
echo "I Like the ${MY_SHELL} shell."
echo "I Like the ${MY_SHELL}ing on my keyboard"
